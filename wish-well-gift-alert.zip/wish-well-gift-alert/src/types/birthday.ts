
export interface Birthday {
  id: string;
  name: string;
  birthDate: string;
  relationship: string;
  interests?: string;
  reminderDays: number;
}
